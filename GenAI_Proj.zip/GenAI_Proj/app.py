import streamlit as st
import subprocess
import sys
import torch
from transformers import pipeline, SpeechT5Processor, SpeechT5ForTextToSpeech, SpeechT5HifiGan
from datasets import load_dataset
import requests
from transformers.pipelines.audio_utils import ffmpeg_microphone_live
from IPython.display import Audio
from transformers import pipeline


# Function to install required packages including SentencePiece
def install_packages():
    subprocess.run("pip install sentencepiece --quiet", shell=True)
    subprocess.run("pip install ipywidgets datasets transformers --quiet", shell=True)
    subprocess.run("pip install --upgrade pip --quiet", shell=True)
    subprocess.run("pip install --upgrade transformers sentencepiece datasets[audio] --quiet", shell=True)

# Automatically install required packages on first load
if 'packages_installed' not in st.session_state:
    install_packages()
    st.session_state.packages_installed = True

st.title('Interactive Audio Processing Application')

device = "cuda:0" if torch.cuda.is_available() else "cpu"
processor = SpeechT5Processor.from_pretrained("microsoft/speecht5_tts")
model = SpeechT5ForTextToSpeech.from_pretrained("microsoft/speecht5_tts").to(device)
vocoder = SpeechT5HifiGan.from_pretrained("microsoft/speecht5_hifigan").to(device)
classifier = pipeline(
    "audio-classification", model="MIT/ast-finetuned-speech-commands-v2", device=device
)

# classifier.model.config.id2label

# classifier.model.config.id2label[27]
# Setup and load models only once
if 'models_loaded' not in st.session_state:
    classifier = pipeline("audio-classification", model="MIT/ast-finetuned-speech-commands-v2", device=device)
    transcriber = pipeline("automatic-speech-recognition", model="openai/whisper-base.en", device=device)
    processor = SpeechT5Processor.from_pretrained("microsoft/speecht5_tts")
    model = SpeechT5ForTextToSpeech.from_pretrained("microsoft/speecht5_tts").to(device)
    vocoder = SpeechT5HifiGan.from_pretrained("microsoft/speecht5_hifigan").to(device)

    # Load speaker embeddings
    embeddings_dataset = load_dataset("Matthijs/cmu-arctic-xvectors", split="validation")
    speaker_embeddings = torch.tensor(embeddings_dataset[0]["xvector"]).unsqueeze(0).to(device)

    st.session_state.classifier = classifier
    st.session_state.transcriber = transcriber
    st.session_state.processor = processor
    st.session_state.model = model
    st.session_state.vocoder = vocoder
    st.session_state.speaker_embeddings = speaker_embeddings
    st.session_state.models_loaded = True
    st.success("Setup completed and models are loaded!")

from transformers.pipelines.audio_utils import ffmpeg_microphone_live


def launch_fn(
    wake_word="marvin",
    prob_threshold=0.5,
    chunk_length_s=2.0,
    stream_chunk_s=0.25,
    debug=False,
):
    if wake_word not in classifier.model.config.label2id.keys():
        raise ValueError(
            f"Wake word {wake_word} not in set of valid class labels, pick a wake word in the set {classifier.model.config.label2id.keys()}."
        )

    sampling_rate = classifier.feature_extractor.sampling_rate

    mic = ffmpeg_microphone_live(
        sampling_rate=sampling_rate,
        chunk_length_s=chunk_length_s,
        stream_chunk_s=stream_chunk_s,
    )

    st.write("Listening for wake word...Marvin")
    for prediction in classifier(mic):
        prediction = prediction[0]
        if debug:
            st.write(prediction)
        if prediction["label"] == wake_word:
            if prediction["score"] > prob_threshold:
                return True   

def transcribe():
    sampling_rate = st.session_state.transcriber.feature_extractor.sampling_rate
    mic = ffmpeg_microphone_live(sampling_rate=sampling_rate, chunk_length_s=5.0, stream_chunk_s=1.0)
    st.write("Start speaking...")
    for item in st.session_state.transcriber(mic, generate_kwargs={"max_new_tokens": 128}):
        sys.stdout.write("\033[K")  # Clear the line
        print(item["text"], end="\r")
        if not item["partial"][0]:
            break
    return item["text"]

import requests


def query(text, model_id="tiiuae/falcon-7b-instruct"):
    api_url = f"https://api-inference.huggingface.co/models/{model_id}"
    headers = {"Authorization": f"Bearer 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"}
    payload = {"inputs": text}

    print(f"Querying...: {text}")
    st.write(f"Querying...: {text}")
    response = requests.post(api_url, headers=headers, json=payload)
    print(response.json())
    return response.json()[0]["generated_text"][len(text) + 1 :]

def synthesise(text):
    inputs = processor(text=text, return_tensors="pt")
    speech = model.generate_speech(
        inputs["input_ids"].to(device), speaker_embeddings.to(device), vocoder=vocoder
    )
    return speech.cpu()

from datasets import load_dataset
embeddings_dataset = load_dataset("Dupaja/cmu-arctic-xvectors", split="validation")
speaker_embeddings = torch.tensor(embeddings_dataset[7306]["xvector"]).unsqueeze(0)

from IPython.display import Audio
# Streamlit UI components
if st.button('Transcribe and Process'):
    launch_fn()
    transcription = transcribe()
    st.write(transcription)
    response = query(transcription)
    st.write(response)
    audio = synthesise(response)
    Audio(audio, rate=16000, autoplay=True)

st.write("Audio generated!.")
